/* Hello World program */

#include<stdio.h>

main()
{
    printf("Hello World");


}
